// security.js - Modul keamanan untuk website

// Sanitasi HTML menggunakan DOMPurify
function sanitizeHTML(html) {
  return DOMPurify.sanitize(html, {
    ALLOWED_TAGS: ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'br', 'a', 'ul', 'ol', 'li', 'b', 'i', 'strong', 'em', 'img', 'blockquote', 'code', 'pre', 'hr', 'table', 'thead', 'tbody', 'tr', 'th', 'td'],
    ALLOWED_ATTR: ['href', 'src', 'alt', 'title', 'style', 'class', 'target', 'width', 'height'],
    ALLOW_DATA_ATTR: false
  });
}

// Enkripsi sederhana untuk data sensitif
function encryptData(data, key) {
  // Implementasi enkripsi sederhana menggunakan XOR
  // Catatan: Ini bukan enkripsi kuat, hanya untuk menambah lapisan keamanan dasar
  let encrypted = '';
  for (let i = 0; i < data.length; i++) {
    encrypted += String.fromCharCode(data.charCodeAt(i) ^ key.charCodeAt(i % key.length));
  }
  return btoa(encrypted); // Base64 encode
}

// Dekripsi data
function decryptData(encryptedData, key) {
  try {
    const data = atob(encryptedData); // Base64 decode
    let decrypted = '';
    for (let i = 0; i < data.length; i++) {
      decrypted += String.fromCharCode(data.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    }
    return decrypted;
  } catch (e) {
    console.error('Decryption failed:', e);
    return null;
  }
}

// Validasi input dasar
function validateInput(input, type) {
  switch(type) {
    case 'email':
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input);
    case 'name':
      return input.length >= 2 && input.length <= 50;
    case 'comment':
      return input.length >= 3 && input.length <= 1000;
    case 'password':
      return input.length >= 8;
    case 'title':
      return input.length >= 3 && input.length <= 100;
    case 'summary':
      return input.length >= 10 && input.length <= 300;
    default:
      return true;
  }
}

// Verifikasi reCAPTCHA
function verifyRecaptcha() {
  const response = grecaptcha.getResponse();
  if (!response) {
    alert('Mohon verifikasi bahwa Anda bukan robot.');
    return false;
  }
  return true;
}

// Checksum untuk deteksi manipulasi data
function generateChecksum(data) {
  let hash = 0;
  if (typeof data === 'object') {
    data = JSON.stringify(data);
  }
  for (let i = 0; i < data.length; i++) {
    const char = data.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return hash.toString(16);
}

// Verifikasi checksum
function verifyChecksum(data, checksum) {
  return generateChecksum(data) === checksum;
}

// Ekspor fungsi-fungsi keamanan
const Security = {
  sanitizeHTML,
  encryptData,
  decryptData,
  validateInput,
  verifyRecaptcha,
  generateChecksum,
  verifyChecksum
};
