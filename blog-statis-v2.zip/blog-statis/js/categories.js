// Categories data for the blog
const categories = [
  {
    id: "teknologi",
    name: "Teknologi",
    description: "Artikel seputar teknologi terbaru, inovasi, dan perkembangan digital",
    icon: "laptop-code",
    color: "#0078AA"
  },
  {
    id: "travel",
    name: "Travel",
    description: "Cerita perjalanan, tips wisata, dan destinasi menarik untuk dikunjungi",
    icon: "plane",
    color: "#FF9F29"
  },
  {
    id: "lifestyle",
    name: "Lifestyle",
    description: "Inspirasi gaya hidup, pengembangan diri, dan tren terkini",
    icon: "coffee",
    color: "#7A4069"
  },
  {
    id: "kuliner",
    name: "Kuliner",
    description: "Ulasan makanan, resep, dan petualangan kuliner",
    icon: "utensils",
    color: "#C21010"
  },
  {
    id: "kesehatan",
    name: "Kesehatan",
    description: "Tips kesehatan, kebugaran, dan kesejahteraan mental",
    icon: "heartbeat",
    color: "#3CCF4E"
  }
];
