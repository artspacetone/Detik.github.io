// Search functionality for the blog
document.addEventListener('DOMContentLoaded', function() {
    // Get search query from URL
    const urlParams = new URLSearchParams(window.location.search);
    const query = urlParams.get('q');
    
    if (query && query.trim() !== '') {
        // Update search term display
        const searchTermElement = document.getElementById('search-term');
        if (searchTermElement) {
            searchTermElement.textContent = query;
        }
        
        // Update search input field
        const searchQueryInput = document.getElementById('search-query');
        if (searchQueryInput) {
            searchQueryInput.value = query;
        }
        
        // Perform search
        const searchResults = searchArticles(query);
        
        // Update search count
        const searchCountElement = document.getElementById('search-count');
        if (searchCountElement) {
            searchCountElement.textContent = `Ditemukan ${searchResults.length} hasil`;
        }
        
        // Display results
        displaySearchResults(searchResults);
    }
});

// Search function
function searchArticles(query) {
    query = query.toLowerCase();
    
    return articles.filter(article => {
        return article.title.toLowerCase().includes(query) || 
               article.summary.toLowerCase().includes(query) || 
               article.tags.some(tag => tag.toLowerCase().includes(query)) ||
               article.categoryLabel.toLowerCase().includes(query);
    });
}

// Display search results
function displaySearchResults(results) {
    const searchResultsContainer = document.getElementById('search-results');
    
    if (!searchResultsContainer) return;
    
    // Clear previous results
    searchResultsContainer.innerHTML = '';
    
    if (results.length === 0) {
        searchResultsContainer.innerHTML = '<p class="text-center">Tidak ada hasil yang ditemukan. Silakan coba kata kunci lain.</p>';
        return;
    }
    
    // Display results
    results.forEach(article => {
        const articleElement = createArticleElement(article);
        searchResultsContainer.appendChild(articleElement);
    });
}

// Create article element
function createArticleElement(article) {
    const articleElement = document.createElement('article');
    articleElement.className = 'post-item';
    
    articleElement.innerHTML = `
        <div class="post-thumbnail">
            <img src="${article.thumbnail}" alt="${article.title}">
        </div>
        <div class="post-content">
            <h3 class="post-title">
                <a href="article.html?id=${article.id}">${article.title}</a>
            </h3>
            <div class="post-meta">
                <span class="post-category">${article.categoryLabel}</span> &bull;
                <span class="post-date">${formatDate(article.date)}</span>
            </div>
            <p class="post-summary">${article.summary}</p>
        </div>
    `;
    
    return articleElement;
}
