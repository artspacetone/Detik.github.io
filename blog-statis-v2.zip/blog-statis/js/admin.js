// admin.js - Fungsi untuk panel admin

document.addEventListener('DOMContentLoaded', function() {
  // Admin password (in a real scenario, use a hashed password)
  const adminPassword = 'admin123';
  
  // Check if already logged in
  checkLoginStatus();
  
  // Setup login form
  setupLoginForm();
  
  // Setup logout button
  setupLogoutButton();
  
  // Setup tab switching
  setupTabSwitching();
  
  // Setup comment filtering
  setupCommentFiltering();
  
  // Setup quick action buttons
  setupQuickActions();
  
  // Function to check login status
  function checkLoginStatus() {
    const isLoggedIn = sessionStorage.getItem('adminLoggedIn') === 'true';
    const loginSection = document.getElementById('login-section');
    const adminPanel = document.getElementById('admin-panel');
    
    if (isLoggedIn && loginSection && adminPanel) {
      loginSection.style.display = 'none';
      adminPanel.style.display = 'block';
      loadAdminData();
    }
  }
  
  // Setup login form
  function setupLoginForm() {
    const loginForm = document.getElementById('admin-login-form');
    
    if (loginForm) {
      loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const password = document.getElementById('admin-password').value;
        
        if (password === adminPassword) {
          // Store login status in sessionStorage (will be cleared when browser is closed)
          sessionStorage.setItem('adminLoggedIn', 'true');
          
          // Hide login section, show admin panel
          document.getElementById('login-section').style.display = 'none';
          document.getElementById('admin-panel').style.display = 'block';
          
          // Load admin data
          loadAdminData();
        } else {
          alert('Password salah!');
        }
      });
    }
  }
  
  // Setup logout button
  function setupLogoutButton() {
    const logoutButton = document.getElementById('logout-button');
    
    if (logoutButton) {
      logoutButton.addEventListener('click', function() {
        // Clear login status
        sessionStorage.removeItem('adminLoggedIn');
        
        // Show login section, hide admin panel
        document.getElementById('login-section').style.display = 'block';
        document.getElementById('admin-panel').style.display = 'none';
      });
    }
  }
  
  // Setup tab switching
  function setupTabSwitching() {
    const tabButtons = document.querySelectorAll('.tab-button');
    
    tabButtons.forEach(button => {
      button.addEventListener('click', function() {
        // Remove active class from all buttons
        tabButtons.forEach(btn => btn.classList.remove('active'));
        
        // Add active class to clicked button
        this.classList.add('active');
        
        // Hide all tab contents
        document.querySelectorAll('.tab-content').forEach(tab => {
          tab.style.display = 'none';
        });
        
        // Show selected tab content
        const tabId = this.getAttribute('data-tab');
        document.getElementById(`${tabId}-tab`).style.display = 'block';
      });
    });
  }
  
  // Setup comment filtering
  function setupCommentFiltering() {
    const filterButtons = document.querySelectorAll('.filter-button');
    
    filterButtons.forEach(button => {
      button.addEventListener('click', function() {
        // Remove active class from all buttons
        filterButtons.forEach(btn => btn.classList.remove('active'));
        
        // Add active class to clicked button
        this.classList.add('active');
        
        // Filter comments
        const filter = this.getAttribute('data-filter');
        filterComments(filter);
      });
    });
  }
  
  // Setup quick action buttons
  function setupQuickActions() {
    const moderateCommentsButton = document.getElementById('moderate-comments-button');
    
    if (moderateCommentsButton) {
      moderateCommentsButton.addEventListener('click', function() {
        // Switch to comments tab
        document.querySelector('.tab-button[data-tab="comments"]').click();
        
        // Filter to show pending comments
        document.querySelector('.filter-button[data-filter="pending"]').click();
      });
    }
  }
});

// Load admin data
function loadAdminData() {
  loadDashboardStats();
  loadArticles();
  loadComments();
}

// Load dashboard stats
function loadDashboardStats() {
  // Get all articles (predefined + user created)
  const predefinedArticles = articles || [];
  const userArticles = JSON.parse(localStorage.getItem('userArticles') || '[]');
  const totalArticles = predefinedArticles.length + userArticles.length;
  
  // Get all comments
  const allComments = JSON.parse(localStorage.getItem('comments') || '[]');
  const pendingComments = allComments.filter(comment => !comment.isApproved);
  
  // Update stats
  document.getElementById('total-articles').textContent = totalArticles;
  document.getElementById('total-comments').textContent = allComments.length;
  document.getElementById('pending-comments').textContent = pendingComments.length;
  
  // Update pending comments badge
  const pendingCommentsBadge = document.getElementById('pending-comments-badge');
  if (pendingCommentsBadge) {
    pendingCommentsBadge.textContent = pendingComments.length;
    pendingCommentsBadge.style.display = pendingComments.length > 0 ? 'inline-block' : 'none';
  }
}

// Load articles
function loadArticles() {
  const articlesList = document.getElementById('articles-list');
  if (!articlesList) return;
  
  // Get all articles (predefined + user created)
  const predefinedArticles = articles || [];
  const userArticles = JSON.parse(localStorage.getItem('userArticles') || '[]');
  const allArticles = [...predefinedArticles, ...userArticles];
  
  // Sort by date (newest first)
  allArticles.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  // Clear list
  articlesList.innerHTML = '';
  
  // Display articles
  allArticles.forEach(article => {
    const articleItem = document.createElement('div');
    articleItem.className = 'admin-item';
    
    articleItem.innerHTML = `
      <div class="admin-item-header">
        <h3>${article.title}</h3>
        <div class="admin-item-meta">
          <span class="category-badge">${article.categoryLabel}</span>
          <span class="date-badge">${formatDate(article.date)}</span>
          ${article.isFeatured ? '<span class="featured-badge">Unggulan</span>' : ''}
        </div>
      </div>
      <div class="admin-item-summary">${article.summary}</div>
      <div class="admin-actions">
        <a href="article.html?id=${article.id}" class="action-button view" target="_blank">Lihat</a>
        <a href="post-editor.html?edit=${article.id}" class="action-button edit">Edit</a>
        <button class="action-button delete" data-id="${article.id}" data-type="article">Hapus</button>
      </div>
    `;
    
    articlesList.appendChild(articleItem);
  });
  
  // Add event listeners for delete buttons
  setupDeleteButtons();
}

// Load comments
function loadComments(filter = 'all') {
  const commentsList = document.getElementById('comments-list');
  if (!commentsList) return;
  
  // Get all comments
  let allComments = JSON.parse(localStorage.getItem('comments') || '[]');
  
  // Apply filter
  if (filter !== 'all') {
    allComments = allComments.filter(comment => {
      if (filter === 'pending') return !comment.isApproved;
      if (filter === 'approved') return comment.isApproved;
      return true;
    });
  }
  
  // Sort by date (newest first)
  allComments.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  // Clear list
  commentsList.innerHTML = '';
  
  // Display message if no comments
  if (allComments.length === 0) {
    commentsList.innerHTML = '<p class="no-items-message">Tidak ada komentar.</p>';
    return;
  }
  
  // Display comments
  allComments.forEach(comment => {
    // Find article title
    const articleTitle = findArticleTitle(comment.articleId);
    
    const commentItem = document.createElement('div');
    commentItem.className = 'admin-item';
    
    // Create rating stars
    let ratingStars = '';
    for (let i = 1; i <= 5; i++) {
      ratingStars += `<span class="star ${i <= comment.rating ? 'filled' : ''}">★</span>`;
    }
    
    commentItem.innerHTML = `
      <div class="admin-item-header">
        <h3>Komentar oleh ${comment.name}</h3>
        <div class="admin-item-meta">
          <span class="article-badge">Artikel: ${articleTitle}</span>
          <span class="date-badge">${formatDate(comment.date)}</span>
          <span class="status-badge ${comment.isApproved ? 'approved' : 'pending'}">
            ${comment.isApproved ? 'Disetujui' : 'Menunggu'}
          </span>
        </div>
      </div>
      <div class="admin-item-content">
        <div class="comment-rating">${ratingStars}</div>
        <p>${comment.text}</p>
      </div>
      <div class="admin-actions">
        <button class="action-button ${comment.isApproved ? 'unapprove' : 'approve'}" data-id="${comment.id}">
          ${comment.isApproved ? 'Batalkan Persetujuan' : 'Setujui'}
        </button>
        <button class="action-button delete" data-id="${comment.id}" data-type="comment">Hapus</button>
      </div>
    `;
    
    commentsList.appendChild(commentItem);
  });
  
  // Add event listeners for approve/unapprove buttons
  setupApproveButtons();
  
  // Add event listeners for delete buttons
  setupDeleteButtons();
}

// Filter comments
function filterComments(filter) {
  loadComments(filter);
}

// Find article title by ID
function findArticleTitle(articleId) {
  // Check predefined articles
  const predefinedArticles = articles || [];
  let article = predefinedArticles.find(a => a.id === articleId);
  
  // If not found, check user articles
  if (!article) {
    const userArticles = JSON.parse(localStorage.getItem('userArticles') || '[]');
    article = userArticles.find(a => a.id === articleId);
  }
  
  return article ? article.title : 'Artikel tidak ditemukan';
}

// Setup approve/unapprove buttons
function setupApproveButtons() {
  document.querySelectorAll('.action-button.approve, .action-button.unapprove').forEach(button => {
    button.addEventListener('click', function() {
      const commentId = parseInt(this.getAttribute('data-id'));
      toggleCommentApproval(commentId);
    });
  });
}

// Setup delete buttons
function setupDeleteButtons() {
  document.querySelectorAll('.action-button.delete').forEach(button => {
    button.addEventListener('click', function() {
      const id = this.getAttribute('data-id');
      const type = this.getAttribute('data-type');
      
      if (confirm(`Apakah Anda yakin ingin menghapus ${type === 'article' ? 'artikel' : 'komentar'} ini?`)) {
        if (type === 'article') {
          deleteArticle(id);
        } else if (type === 'comment') {
          deleteComment(parseInt(id));
        }
      }
    });
  });
}

// Toggle comment approval
function toggleCommentApproval(commentId) {
  // Get all comments
  let comments = JSON.parse(localStorage.getItem('comments') || '[]');
  
  // Find comment
  const index = comments.findIndex(comment => comment.id === commentId);
  
  if (index !== -1) {
    // Toggle approval
    comments[index].isApproved = !comments[index].isApproved;
    
    // Update checksum
    const commentWithoutChecksum = {...comments[index], checksum: undefined};
    comments[index].checksum = Security.generateChecksum(commentWithoutChecksum);
    
    // Save back to localStorage
    localStorage.setItem('comments', JSON.stringify(comments));
    
    // Reload comments and dashboard
    loadComments();
    loadDashboardStats();
  }
}

// Delete article
function deleteArticle(articleId) {
  // For predefined articles, we can't actually delete them
  // For user articles, we can remove from localStorage
  let userArticles = JSON.parse(localStorage.getItem('userArticles') || '[]');
  
  // Check if article exists in user articles
  const index = userArticles.findIndex(article => article.id === articleId);
  
  if (index !== -1) {
    // Remove from user articles
    userArticles.splice(index, 1);
    localStorage.setItem('userArticles', JSON.stringify(userArticles));
    
    // Reload articles and dashboard
    loadArticles();
    loadDashboardStats();
  } else {
    alert('Artikel ini tidak dapat dihapus karena merupakan artikel default.');
  }
}

// Delete comment
function deleteComment(commentId) {
  // Get all comments
  let comments = JSON.parse(localStorage.getItem('comments') || '[]');
  
  // Filter out the comment to delete
  comments = comments.filter(comment => comment.id !== commentId);
  
  // Save back to localStorage
  localStorage.setItem('comments', JSON.stringify(comments));
  
  // Reload comments and dashboard
  loadComments();
  loadDashboardStats();
}

// Format date
function formatDate(dateString) {
  const options = { year: 'numeric', month: 'long', day: 'numeric' };
  const date = new Date(dateString);
  return date.toLocaleDateString('id-ID', options);
}
