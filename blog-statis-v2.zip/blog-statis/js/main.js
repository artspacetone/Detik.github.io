// Main JavaScript for Blog Website

document.addEventListener('DOMContentLoaded', function() {
    // Menu Toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const mainNav = document.querySelector('.main-nav');
    const navOverlay = document.querySelector('.nav-overlay');
    const navClose = document.querySelector('.nav-close');

    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            mainNav.classList.add('active');
            navOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    }

    if (navClose) {
        navClose.addEventListener('click', function() {
            mainNav.classList.remove('active');
            navOverlay.classList.remove('active');
            document.body.style.overflow = '';
        });
    }

    if (navOverlay) {
        navOverlay.addEventListener('click', function() {
            mainNav.classList.remove('active');
            navOverlay.classList.remove('active');
            document.body.style.overflow = '';
        });
    }

    // Search Toggle
    const searchToggle = document.querySelector('.search-toggle');
    const searchOverlay = document.querySelector('.search-overlay');
    const searchClose = document.querySelector('.search-close');
    const searchInput = document.querySelector('.search-overlay .search-input');

    if (searchToggle) {
        searchToggle.addEventListener('click', function() {
            searchOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
            if (searchInput) {
                setTimeout(() => {
                    searchInput.focus();
                }, 100);
            }
        });
    }

    if (searchClose) {
        searchClose.addEventListener('click', function() {
            searchOverlay.classList.remove('active');
            document.body.style.overflow = '';
        });
    }

    // Escape key closes menus and search
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            mainNav.classList.remove('active');
            navOverlay.classList.remove('active');
            searchOverlay.classList.remove('active');
            document.body.style.overflow = '';
        }
    });

    // Lazy loading images
    if ('loading' in HTMLImageElement.prototype) {
        const images = document.querySelectorAll('img[loading="lazy"]');
        images.forEach(img => {
            img.src = img.dataset.src;
        });
    } else {
        // Fallback for browsers that don't support lazy loading
        const script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/lazysizes/5.3.2/lazysizes.min.js';
        document.body.appendChild(script);
    }

    // Comment form handling (for demo purposes)
    const commentForm = document.getElementById('comment-form');
    if (commentForm) {
        commentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('comment-name').value;
            const email = document.getElementById('comment-email').value;
            const text = document.getElementById('comment-text').value;
            
            alert(`Terima kasih ${name} atas komentar Anda! Dalam website statis ini, komentar tidak akan disimpan secara permanen. Pada implementasi sebenarnya, Anda dapat mengintegrasikan dengan layanan komentar seperti Disqus atau formulir yang mengirim data ke Google Forms.`);
            
            // Reset form
            commentForm.reset();
        });
    }

    // Highlight active category in navigation
    const highlightActiveCategory = () => {
        const urlParams = new URLSearchParams(window.location.search);
        const categoryId = urlParams.get('id');
        
        if (categoryId) {
            const categoryLinks = document.querySelectorAll('.category-link');
            categoryLinks.forEach(link => {
                if (link.href.includes(`id=${categoryId}`)) {
                    link.style.fontWeight = 'bold';
                    link.style.color = 'var(--primary-color)';
                }
            });
        }
    };
    
    highlightActiveCategory();
});

// Helper functions
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', options);
}
