// Category page functionality
document.addEventListener('DOMContentLoaded', function() {
    // Get category ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const categoryId = urlParams.get('id');
    
    if (categoryId) {
        // Find category data
        const category = categories.find(cat => cat.id === categoryId);
        
        if (category) {
            // Update page title and description
            document.title = `${category.name} - Blog Pribadi`;
            
            const categoryTitleElement = document.getElementById('category-title');
            if (categoryTitleElement) {
                categoryTitleElement.textContent = category.name;
            }
            
            const categoryDescriptionElement = document.getElementById('category-description');
            if (categoryDescriptionElement) {
                categoryDescriptionElement.textContent = category.description;
            }
            
            // Filter articles by category
            const categoryArticles = articles.filter(article => article.category === categoryId);
            
            // Display category articles
            displayCategoryArticles(categoryArticles);
        } else {
            // Category not found
            handleCategoryNotFound();
        }
    } else {
        // No category ID provided
        handleCategoryNotFound();
    }
});

// Display category articles
function displayCategoryArticles(categoryArticles) {
    const categoryPostsContainer = document.getElementById('category-posts');
    
    if (!categoryPostsContainer) return;
    
    // Clear previous content
    categoryPostsContainer.innerHTML = '';
    
    if (categoryArticles.length === 0) {
        categoryPostsContainer.innerHTML = '<p class="text-center">Tidak ada artikel dalam kategori ini.</p>';
        return;
    }
    
    // Display articles
    categoryArticles.forEach(article => {
        const articleElement = createArticleElement(article);
        categoryPostsContainer.appendChild(articleElement);
    });
}

// Create article element
function createArticleElement(article) {
    const articleElement = document.createElement('article');
    articleElement.className = 'post-item';
    
    articleElement.innerHTML = `
        <div class="post-thumbnail">
            <img src="${article.thumbnail}" alt="${article.title}">
        </div>
        <div class="post-content">
            <h3 class="post-title">
                <a href="article.html?id=${article.id}">${article.title}</a>
            </h3>
            <div class="post-meta">
                <span class="post-category">${article.categoryLabel}</span> &bull;
                <span class="post-date">${formatDate(article.date)}</span>
            </div>
            <p class="post-summary">${article.summary}</p>
        </div>
    `;
    
    return articleElement;
}

// Handle category not found
function handleCategoryNotFound() {
    const categoryTitleElement = document.getElementById('category-title');
    if (categoryTitleElement) {
        categoryTitleElement.textContent = 'Kategori Tidak Ditemukan';
    }
    
    const categoryDescriptionElement = document.getElementById('category-description');
    if (categoryDescriptionElement) {
        categoryDescriptionElement.textContent = 'Kategori yang Anda cari tidak ditemukan.';
    }
    
    const categoryPostsContainer = document.getElementById('category-posts');
    if (categoryPostsContainer) {
        categoryPostsContainer.innerHTML = '<p class="text-center">Silakan kembali ke <a href="index.html">halaman utama</a>.</p>';
    }
}
