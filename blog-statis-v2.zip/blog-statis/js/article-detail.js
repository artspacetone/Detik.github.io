// Article detail page functionality
document.addEventListener('DOMContentLoaded', function() {
    // Get article ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const articleId = urlParams.get('id');
    
    if (articleId) {
        // Find article data
        const article = articles.find(art => art.id === articleId);
        
        if (article) {
            // Update page title
            document.title = `${article.title} - Blog Pribadi`;
            
            // Update article elements
            updateArticleElements(article);
            
            // Load related articles
            loadRelatedArticles(article);
        } else {
            // Article not found
            handleArticleNotFound();
        }
    } else {
        // No article ID provided
        handleArticleNotFound();
    }
});

// Update article elements with data
function updateArticleElements(article) {
    // Update title
    const titleElement = document.getElementById('article-title');
    if (titleElement) {
        titleElement.textContent = article.title;
    }
    
    // Update category
    const categoryElement = document.getElementById('article-category');
    if (categoryElement) {
        categoryElement.textContent = article.categoryLabel;
    }
    
    // Update date
    const dateElement = document.getElementById('article-date');
    if (dateElement) {
        dateElement.textContent = formatDate(article.date);
    }
    
    // Update featured image
    const imageElement = document.getElementById('article-image');
    if (imageElement) {
        imageElement.src = article.featuredImage;
        imageElement.alt = article.title;
    }
    
    // Update tags
    const tagsElement = document.getElementById('article-tags');
    if (tagsElement && article.tags) {
        tagsElement.innerHTML = '';
        article.tags.forEach(tag => {
            const tagSpan = document.createElement('span');
            tagSpan.className = 'tag';
            tagSpan.textContent = tag;
            tagsElement.appendChild(tagSpan);
        });
    }
    
    // Note: Content is already in the HTML for this static version
    // In a more dynamic version, we would load content from a separate file
}

// Load related articles
function loadRelatedArticles(currentArticle) {
    const relatedPostsContainer = document.getElementById('related-posts');
    
    if (!relatedPostsContainer) return;
    
    // Find articles in the same category, excluding current article
    const relatedArticles = articles
        .filter(article => article.category === currentArticle.category && article.id !== currentArticle.id)
        .slice(0, 2); // Limit to 2 related articles
    
    if (relatedArticles.length === 0) {
        relatedPostsContainer.innerHTML = '<p class="text-center">Tidak ada artikel terkait.</p>';
        return;
    }
    
    // Clear previous content
    relatedPostsContainer.innerHTML = '';
    
    // Display related articles
    relatedArticles.forEach(article => {
        const articleElement = document.createElement('article');
        articleElement.className = 'post-item';
        
        articleElement.innerHTML = `
            <div class="post-thumbnail">
                <img src="${article.thumbnail}" alt="${article.title}">
            </div>
            <div class="post-content">
                <h3 class="post-title">
                    <a href="article.html?id=${article.id}">${article.title}</a>
                </h3>
                <div class="post-meta">
                    <span class="post-category">${article.categoryLabel}</span> &bull;
                    <span class="post-date">${formatDate(article.date)}</span>
                </div>
            </div>
        `;
        
        relatedPostsContainer.appendChild(articleElement);
    });
}

// Handle article not found
function handleArticleNotFound() {
    const articleTitle = document.getElementById('article-title');
    if (articleTitle) {
        articleTitle.textContent = 'Artikel Tidak Ditemukan';
    }
    
    const articleContent = document.getElementById('article-content');
    if (articleContent) {
        articleContent.innerHTML = '<p class="text-center">Artikel yang Anda cari tidak ditemukan. Silakan kembali ke <a href="index.html">halaman utama</a>.</p>';
    }
    
    // Hide other elements
    const elements = ['article-image', 'article-tags', 'related-articles', 'comments-section'];
    elements.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.style.display = 'none';
        }
    });
}
