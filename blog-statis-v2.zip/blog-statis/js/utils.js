// Utility functions for the blog
function formatDate(dateString) {
  const options = { year: 'numeric', month: 'long', day: 'numeric' };
  const date = new Date(dateString);
  return date.toLocaleDateString('id-ID', options);
}

// Function to get URL parameters
function getUrlParameter(name) {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get(name);
}

// Function to combine articles from predefined and user-created sources
function getAllArticles() {
  // Get predefined articles
  const predefinedArticles = articles || [];
  
  // Get user-created articles from localStorage
  const userArticles = JSON.parse(localStorage.getItem('userArticles') || '[]');
  
  // Combine and sort by date (newest first)
  const allArticles = [...predefinedArticles, ...userArticles];
  allArticles.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  return allArticles;
}

// Function to find article by ID
function findArticleById(id) {
  // First check predefined articles
  const predefinedArticles = articles || [];
  let article = predefinedArticles.find(a => a.id === id);
  
  // If not found, check user articles
  if (!article) {
    const userArticles = JSON.parse(localStorage.getItem('userArticles') || '[]');
    article = userArticles.find(a => a.id === id);
  }
  
  return article;
}

// Function to create article element for display
function createArticleElement(article) {
  const articleElement = document.createElement('article');
  articleElement.className = 'post-item';
  
  articleElement.innerHTML = `
    <div class="post-thumbnail">
      <a href="article.html?id=${article.id}">
        <img src="${article.thumbnail}" alt="${article.title}">
      </a>
    </div>
    <div class="post-content">
      <h3 class="post-title">
        <a href="article.html?id=${article.id}">${article.title}</a>
      </h3>
      <div class="post-meta">
        <a href="category.html?id=${article.category}" class="post-category">${article.categoryLabel}</a> &bull;
        <span class="post-date">${formatDate(article.date)}</span>
      </div>
      <p class="post-summary">${article.summary}</p>
      <a href="article.html?id=${article.id}" class="read-more">Baca Selengkapnya</a>
    </div>
  `;
  
  return articleElement;
}

// Auto logout for admin panel after inactivity
function setupAutoLogout() {
  // Only setup if user is logged in
  if (sessionStorage.getItem('adminLoggedIn') !== 'true') return;
  
  // Set timeout to 30 minutes
  const logoutTime = 30 * 60 * 1000; // 30 minutes in milliseconds
  let logoutTimer;
  
  // Function to reset timer
  function resetTimer() {
    clearTimeout(logoutTimer);
    logoutTimer = setTimeout(logout, logoutTime);
  }
  
  // Function to logout
  function logout() {
    sessionStorage.removeItem('adminLoggedIn');
    alert('Sesi Anda telah berakhir karena tidak ada aktivitas. Silakan login kembali.');
    window.location.href = 'admin.html';
  }
  
  // Reset timer on user activity
  ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'].forEach(event => {
    document.addEventListener(event, resetTimer, false);
  });
  
  // Start timer
  resetTimer();
}
