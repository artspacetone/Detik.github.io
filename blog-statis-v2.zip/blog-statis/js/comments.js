// comments.js - Sistem komentar untuk blog

document.addEventListener('DOMContentLoaded', function() {
  const commentForm = document.getElementById('comment-form');
  const commentsContainer = document.getElementById('comments-list');
  
  if (commentForm && commentsContainer) {
    // Get article ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const articleId = urlParams.get('id');
    
    if (articleId) {
      // Load existing comments
      loadComments(articleId);
      
      // Setup comment form submission
      commentForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validate form
        if (!validateCommentForm()) return;
        
        // Get comment data
        const commentData = getCommentFormData(articleId);
        
        // Save comment
        saveComment(commentData);
        
        // Reset form
        commentForm.reset();
        grecaptcha.reset();
        
        // Reload comments
        loadComments(articleId);
        
        // Show success message
        alert('Komentar Anda telah dikirim dan sedang menunggu moderasi.');
      });
    }
  }
});

// Validate comment form
function validateCommentForm() {
  // Get form data
  const name = document.getElementById('comment-name').value.trim();
  const email = document.getElementById('comment-email').value.trim();
  const text = document.getElementById('comment-text').value.trim();
  
  // Validate with security module
  if (!Security.validateInput(name, 'name')) {
    alert('Nama tidak valid. Gunakan 2-50 karakter.');
    return false;
  }
  
  if (!Security.validateInput(email, 'email')) {
    alert('Email tidak valid.');
    return false;
  }
  
  if (!Security.validateInput(text, 'comment')) {
    alert('Komentar tidak valid. Gunakan 3-1000 karakter.');
    return false;
  }
  
  // Verify reCAPTCHA
  if (!Security.verifyRecaptcha()) {
    return false;
  }
  
  return true;
}

// Get comment form data
function getCommentFormData(articleId) {
  // Get form data
  const name = document.getElementById('comment-name').value.trim();
  const email = document.getElementById('comment-email').value.trim();
  const text = document.getElementById('comment-text').value.trim();
  const rating = document.querySelector('input[name="rating"]:checked')?.value || '0';
  
  // Create comment object
  const comment = {
    id: Date.now(),
    articleId: articleId,
    name: name,
    email: Security.encryptData(email, 'comment-email-key'), // Encrypt email for privacy
    text: Security.sanitizeHTML(text), // Sanitize HTML
    rating: parseInt(rating),
    date: new Date().toISOString(),
    isApproved: false // Require moderation by default
  };
  
  // Add checksum for security
  comment.checksum = Security.generateChecksum(comment);
  
  return comment;
}

// Save comment
function saveComment(comment) {
  // Get existing comments
  let comments = JSON.parse(localStorage.getItem('comments') || '[]');
  
  // Add new comment
  comments.push(comment);
  
  // Save back to localStorage
  localStorage.setItem('comments', JSON.stringify(comments));
}

// Load comments for an article
function loadComments(articleId) {
  const commentsContainer = document.getElementById('comments-list');
  if (!commentsContainer) return;
  
  // Get all comments
  const allComments = JSON.parse(localStorage.getItem('comments') || '[]');
  
  // Filter comments for this article that are approved
  const articleComments = allComments.filter(comment => 
    comment.articleId === articleId && comment.isApproved
  );
  
  // Update comments count
  const commentsTitle = document.querySelector('.comments-title');
  if (commentsTitle) {
    commentsTitle.textContent = `Komentar (${articleComments.length})`;
  }
  
  // Clear comments container
  commentsContainer.innerHTML = '';
  
  // Display message if no comments
  if (articleComments.length === 0) {
    commentsContainer.innerHTML = '<p>Belum ada komentar. Jadilah yang pertama berkomentar!</p>';
    return;
  }
  
  // Sort comments by date (newest first)
  articleComments.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  // Display comments
  articleComments.forEach(comment => {
    // Verify checksum to prevent tampering
    if (!Security.verifyChecksum({...comment, checksum: undefined}, comment.checksum)) {
      console.warn('Comment checksum verification failed:', comment.id);
      return; // Skip this comment
    }
    
    const commentElement = document.createElement('div');
    commentElement.className = 'comment';
    
    // Format date
    const commentDate = new Date(comment.date);
    const formattedDate = commentDate.toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    
    // Create rating stars
    let ratingStars = '';
    for (let i = 1; i <= 5; i++) {
      ratingStars += `<span class="star ${i <= comment.rating ? 'filled' : ''}">★</span>`;
    }
    
    commentElement.innerHTML = `
      <div class="comment-meta">
        <strong>${comment.name}</strong> &bull;
        <span class="comment-date">${formattedDate}</span>
        <div class="comment-rating">${ratingStars}</div>
      </div>
      <div class="comment-content">
        <p>${comment.text}</p>
      </div>
    `;
    
    commentsContainer.appendChild(commentElement);
  });
}
