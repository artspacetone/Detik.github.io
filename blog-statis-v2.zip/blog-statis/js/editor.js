// editor.js - Fungsi untuk editor posting HTML

document.addEventListener('DOMContentLoaded', function() {
  // Initialize TinyMCE
  tinymce.init({
    selector: '#post-content',
    plugins: 'advlist autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table paste code help wordcount',
    toolbar: 'undo redo | formatselect | bold italic backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | link image | help',
    height: 500,
    images_upload_handler: handleImageUpload,
    content_style: 'body { font-family: "Roboto", sans-serif; font-size: 16px; }',
    setup: function(editor) {
      editor.on('change', function() {
        editor.save();
      });
    }
  });
  
  // Load categories into select dropdown
  loadCategories();
  
  // Check if we're in edit mode
  checkEditMode();
  
  // Setup form submission
  setupFormSubmission();
  
  // Setup preview button
  setupPreviewButton();
});

// Load categories into select dropdown
function loadCategories() {
  const categorySelect = document.getElementById('post-category');
  if (!categorySelect) return;
  
  // Clear existing options except the first one
  while (categorySelect.options.length > 1) {
    categorySelect.remove(1);
  }
  
  // Add categories from categories.js
  categories.forEach(category => {
    const option = document.createElement('option');
    option.value = category.id;
    option.textContent = category.name;
    categorySelect.appendChild(option);
  });
}

// Check if we're in edit mode
function checkEditMode() {
  const urlParams = new URLSearchParams(window.location.search);
  const editId = urlParams.get('edit');
  
  if (editId) {
    // We're in edit mode
    document.getElementById('editor-title').textContent = 'Edit Artikel';
    document.getElementById('publish-button').textContent = 'Perbarui';
    
    // Find the article
    const article = findArticleById(editId);
    
    if (article) {
      // Populate form with article data
      document.getElementById('post-title').value = article.title;
      document.getElementById('post-category').value = article.category;
      document.getElementById('post-summary').value = article.summary;
      document.getElementById('post-tags').value = article.tags.join(', ');
      document.getElementById('post-featured').checked = article.isFeatured;
      document.getElementById('post-id').value = article.id;
      document.getElementById('post-date').value = article.date;
      
      // Set content in TinyMCE
      // We need to wait for TinyMCE to initialize
      const checkTinyMCE = setInterval(() => {
        if (tinymce.get('post-content')) {
          tinymce.get('post-content').setContent(article.content);
          clearInterval(checkTinyMCE);
        }
      }, 100);
    } else {
      alert('Artikel tidak ditemukan.');
      window.location.href = 'admin.html';
    }
  }
}

// Find article by ID
function findArticleById(id) {
  // First check predefined articles
  let article = articles.find(a => a.id === id);
  
  // If not found, check user articles
  if (!article) {
    const userArticles = JSON.parse(localStorage.getItem('userArticles') || '[]');
    article = userArticles.find(a => a.id === id);
  }
  
  return article;
}

// Setup form submission
function setupFormSubmission() {
  const postForm = document.getElementById('post-form');
  if (!postForm) return;
  
  postForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Validate form
    if (!validateForm()) return;
    
    // Get form data
    const articleData = getFormData();
    
    // Save article
    saveArticle(articleData);
    
    // Show success message and redirect
    alert(document.getElementById('post-id').value ? 'Artikel berhasil diperbarui!' : 'Artikel berhasil dipublikasikan!');
    window.location.href = 'admin.html';
  });
}

// Validate form
function validateForm() {
  // Check required fields
  const title = document.getElementById('post-title').value.trim();
  const category = document.getElementById('post-category').value;
  const summary = document.getElementById('post-summary').value.trim();
  const content = tinymce.get('post-content').getContent();
  
  if (!title || !category || !summary || !content) {
    alert('Mohon lengkapi semua field yang diperlukan.');
    return false;
  }
  
  // Validate with security module
  if (!Security.validateInput(title, 'title')) {
    alert('Judul artikel tidak valid.');
    return false;
  }
  
  if (!Security.validateInput(summary, 'summary')) {
    alert('Ringkasan artikel tidak valid.');
    return false;
  }
  
  // Verify reCAPTCHA
  if (!Security.verifyRecaptcha()) {
    return false;
  }
  
  return true;
}

// Get form data
function getFormData() {
  const isEditMode = !!document.getElementById('post-id').value;
  
  // Get basic data
  const title = document.getElementById('post-title').value.trim();
  const category = document.getElementById('post-category').value;
  const categoryLabel = document.querySelector(`#post-category option[value="${category}"]`).textContent;
  const summary = document.getElementById('post-summary').value.trim();
  const content = tinymce.get('post-content').getContent();
  const tags = document.getElementById('post-tags').value.split(',').map(tag => tag.trim()).filter(tag => tag);
  const isFeatured = document.getElementById('post-featured').checked;
  
  // Generate slug from title
  const slug = title.toLowerCase()
    .replace(/[^\w ]+/g, '')
    .replace(/ +/g, '-');
  
  // Create article object
  const article = {
    id: isEditMode ? document.getElementById('post-id').value : 'article-' + Date.now(),
    title: title,
    slug: slug,
    date: isEditMode ? document.getElementById('post-date').value : new Date().toISOString().split('T')[0],
    category: category,
    categoryLabel: categoryLabel,
    tags: tags,
    thumbnail: 'images/articles/default-thumbnail.jpg', // Default image
    featuredImage: 'images/articles/default-featured.jpg', // Default image
    summary: summary,
    content: Security.sanitizeHTML(content), // Sanitize HTML content
    isFeatured: isFeatured
  };
  
  // Add checksum for security
  article.checksum = Security.generateChecksum(article);
  
  return article;
}

// Save article
function saveArticle(article) {
  // Get existing user articles
  let userArticles = JSON.parse(localStorage.getItem('userArticles') || '[]');
  
  // Check if we're updating an existing article
  const existingIndex = userArticles.findIndex(a => a.id === article.id);
  
  if (existingIndex !== -1) {
    // Update existing article
    userArticles[existingIndex] = article;
  } else {
    // Add new article
    userArticles.push(article);
  }
  
  // Save back to localStorage
  localStorage.setItem('userArticles', JSON.stringify(userArticles));
}

// Handle image upload for TinyMCE
function handleImageUpload(blobInfo, success, failure) {
  // In a static site, we can't upload images to server
  // Instead, we convert to base64 and store inline
  const reader = new FileReader();
  reader.onload = function() {
    success(reader.result);
  };
  reader.onerror = function() {
    failure('Image upload failed');
  };
  reader.readAsDataURL(blobInfo.blob());
}

// Setup preview button
function setupPreviewButton() {
  const previewButton = document.getElementById('preview-button');
  const previewModal = document.getElementById('preview-modal');
  const modalClose = document.querySelector('.modal-close');
  
  if (previewButton && previewModal) {
    previewButton.addEventListener('click', function() {
      // Get content from TinyMCE
      const title = document.getElementById('post-title').value.trim();
      const content = tinymce.get('post-content').getContent();
      
      // Display preview
      const previewContainer = document.getElementById('preview-container');
      previewContainer.innerHTML = `
        <h1>${title}</h1>
        <div class="article-content">${Security.sanitizeHTML(content)}</div>
      `;
      
      // Show modal
      previewModal.style.display = 'block';
    });
    
    // Close modal when clicking X
    if (modalClose) {
      modalClose.addEventListener('click', function() {
        previewModal.style.display = 'none';
      });
    }
    
    // Close modal when clicking outside
    window.addEventListener('click', function(e) {
      if (e.target === previewModal) {
        previewModal.style.display = 'none';
      }
    });
  }
}
